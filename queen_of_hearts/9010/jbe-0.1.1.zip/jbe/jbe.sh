cd bin
java ee.ioc.cs.jbe.browser.BrowserApplication